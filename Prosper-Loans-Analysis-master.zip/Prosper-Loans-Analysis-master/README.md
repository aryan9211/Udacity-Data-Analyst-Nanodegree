# Prosper-Loans-Analysis

## Prosper Lending: Who Are The Most Profitable Borrowers?

This notebook is aimed at looking into the main value drivers of the P2P Lending marketplace Prosper, to ascertain which loans drive the revenues and perform a profiling of the most profitable borrowers.

The main value drivers are:

- **Number of Originations**: indicates the ability to attract borrowers.

- **Servicing Fees and Origination Fees**: they comprise the core revenue stream for Porsper. For the aim of this analysis only Origination Fees are going to be considered as woth the data available is not possible to carry out a thorough analysis of Servicing Fees.

- **Lender Returns**: they are pivotal to attract lender on the platform. Loan must offer a decent return (given a certain risk level) to attract lenders (Servicing Fees)


The **Origination Fees** are the focus of our analysis. They are calucated as a percentage (depending on the risk profile) of the amount requested by the borrower. Therefore the main variables involved are:

- The Prosper Rating of the borrower.
- The amount requested by the borrower.
